<?php
// ============================================================
// ไฟล์: admin_items.php
// หน้าที่: หน้าจัดการอุปกรณ์สำหรับแอดมิน
//   - เพิ่มอุปกรณ์ใหม่ (พร้อมอัปโหลดรูป)
//   - ปรับจำนวนอุปกรณ์ทั้งหมด
//   - ลบอุปกรณ์
//   - แสดงรายการอุปกรณ์ทั้งหมดในตาราง
// ============================================================

// เรียกไฟล์เชื่อมต่อฐานข้อมูล (ได้ตัวแปร $conn) และแถบเมนูด้านบน
require_once 'db.php';
require_once 'navbar.php';

// ตรวจสิทธิ์: ถ้าไม่ใช่แอดมินให้หยุดการทำงานทันทีและแสดงข้อความ
if ($_SESSION['role'] !== 'admin') {
    die("<div class='msg-error-page'>สำหรับแอดมินเท่านั้น</div>");
}

// ตัวแปรเก็บข้อความแจ้งผล (สำเร็จ / ผิดพลาด) เพื่อแสดงบนหน้าเว็บ
$msg_ok = '';
$msg_err = '';

// ทำงานเฉพาะตอนที่มีการส่งฟอร์มแบบ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // อ่านค่า action เพื่อรู้ว่าฟอร์มไหนถูกส่งมา (add / set_qty / delete)
    $action = $_POST['action'] ?? 'add';

    // ==================== เพิ่มอุปกรณ์ ====================
    if ($action === 'add') {
        // รับค่าจากฟอร์ม ตัดช่องว่างหัวท้ายด้วย trim
        $item_code = trim($_POST['item_code']);
        $item_name = trim($_POST['item_name']);
        // หมวดหมู่มีได้แค่ 2 ค่า ถ้าไม่ใช่ boardgame ให้เป็น sports
        $category  = $_POST['category'] === 'boardgame' ? 'boardgame' : 'sports';
        // แปลงจำนวนเป็นตัวเลขจำนวนเต็ม (ถ้าไม่ส่งมาใช้ 1)
        $qty       = intval($_POST['total_qty'] ?? 1);
        $image_name = NULL; // ชื่อไฟล์รูป (ยังไม่มีรูปให้เป็น NULL)

        // ตรวจว่าจำนวนต้องไม่น้อยกว่า 1
        if ($qty < 1) {
            $msg_err = "จำนวนต้องอย่างน้อย 1 ชิ้น";
        } else {
            // ---- ส่วนอัปโหลดรูปภาพ ----
            // ตรวจว่ามีการแนบไฟล์และอัปโหลดสำเร็จ
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                // ดึงนามสกุลไฟล์ แล้วแปลงเป็นตัวพิมพ์เล็ก
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                // อนุญาตเฉพาะไฟล์รูปภาพเท่านั้น (ป้องกันการอัปโหลดไฟล์อันตราย)
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                    // ตั้งชื่อไฟล์ใหม่ไม่ให้ซ้ำกัน (เวลา + uniqid)
                    $image_name = time() . '_' . uniqid() . '.' . $ext;
                    // ถ้ายังไม่มีโฟลเดอร์ uploads ให้สร้างขึ้นมา
                    if (!is_dir('uploads')) {
                        mkdir('uploads', 0755, true);
                    }
                    // ย้ายไฟล์จากที่เก็บชั่วคราวไปยังโฟลเดอร์ uploads
                    move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $image_name);
                }
            }

            // ---- บันทึกลงฐานข้อมูล ----
            // จำนวนทั้งหมด = จำนวนคงเหลือ ตอนเพิ่มใหม่
            // ใช้ prepared statement เพื่อป้องกัน SQL Injection
            $stmt = $conn->prepare(
                "INSERT INTO items (item_code, item_name, category, total_qty, available_qty, image, status)
                 VALUES (?, ?, ?, ?, ?, ?, 'available')"
            );
            // s = string, i = integer (รหัส, ชื่อ, หมวด, จำนวนทั้งหมด, จำนวนคงเหลือ, รูป)
            $stmt->bind_param("sssiis", $item_code, $item_name, $category, $qty, $qty, $image_name);
            $stmt->execute();

            // redirect กลับหน้าเดิมพร้อมแจ้งว่าเพิ่มสำเร็จ
            // (ป้องกันการกด refresh แล้วส่งฟอร์มซ้ำ)
            header("Location: admin_items.php?ok=added");
            exit();
        }
    }

    // ==================== ปรับจำนวนอุปกรณ์ ====================
    if ($action === 'set_qty') {
        $item_id = intval($_POST['item_id']);       // อุปกรณ์ที่จะปรับ
        $new_total = intval($_POST['total_qty']);   // จำนวนทั้งหมดใหม่

        // เริ่ม transaction เพื่อให้การอ่าน+แก้ไขข้อมูลปลอดภัย
        $conn->begin_transaction();
        // FOR UPDATE = ล็อกแถวนี้ไว้ ไม่ให้คนอื่นแก้ไขพร้อมกัน
        $s = $conn->prepare("SELECT total_qty, available_qty FROM items WHERE item_id = ? FOR UPDATE");
        $s->bind_param("i", $item_id);
        $s->execute();
        $it = $s->get_result()->fetch_assoc();

        if (!$it) {
            // ไม่พบอุปกรณ์ -> ยกเลิก transaction
            $conn->rollback();
            $msg_err = "ไม่พบอุปกรณ์";
        } else {
            // คำนวณจำนวนที่ถูกยืมอยู่ = ทั้งหมด - คงเหลือ
            $borrowed = (int)$it['total_qty'] - (int)$it['available_qty'];
            // จำนวนใหม่ต้องไม่น้อยกว่าจำนวนที่ถูกยืมอยู่ (ไม่งั้นของจะติดลบ)
            if ($new_total < $borrowed || $new_total < 0) {
                $conn->rollback();
                $msg_err = "ปรับไม่ได้ ขณะนี้มีของถูกยืมอยู่ $borrowed ชิ้น (จำนวนทั้งหมดต้องไม่น้อยกว่านี้)";
            } else {
                // จำนวนคงเหลือใหม่ = จำนวนทั้งหมดใหม่ - จำนวนที่ถูกยืม
                $new_avail = $new_total - $borrowed;
                // อัปเดตจำนวน และตั้งสถานะ: ถ้าเหลือ > 0 = available, ถ้าหมด = borrowed
                $u = $conn->prepare("UPDATE items
                                     SET total_qty = ?, available_qty = ?,
                                         status = IF(? > 0, 'available', 'borrowed')
                                     WHERE item_id = ?");
                $u->bind_param("iiii", $new_total, $new_avail, $new_avail, $item_id);
                $u->execute();
                $conn->commit(); // ยืนยันการเปลี่ยนแปลง
                header("Location: admin_items.php?ok=qty");
                exit();
            }
        }
    }

    // ==================== ลบอุปกรณ์ ====================
    if ($action === 'delete') {
        $item_id = intval($_POST['item_id']);

        // ห้ามลบถ้ามีรายการยืมที่ยังไม่คืน
        // นับจำนวนรายการยืมที่ status = 'active' ของอุปกรณ์นี้
        $c = $conn->prepare("SELECT COUNT(*) AS n FROM loans WHERE item_id = ? AND status = 'active'");
        $c->bind_param("i", $item_id);
        $c->execute();
        $active = (int)$c->get_result()->fetch_assoc()['n'];

        if ($active > 0) {
            $msg_err = "ลบไม่ได้ เพราะยังมีรายการยืมที่ยังไม่คืน";
        } else {
            // ดึงชื่อไฟล์รูปของอุปกรณ์ เพื่อลบไฟล์รูปออกจากเซิร์ฟเวอร์ด้วย
            $q = $conn->prepare("SELECT image FROM items WHERE item_id = ?");
            $q->bind_param("i", $item_id);
            $q->execute();
            $img = $q->get_result()->fetch_assoc();
            // ถ้ามีรูปและไฟล์มีอยู่จริง ให้ลบไฟล์ทิ้ง
            if (!empty($img['image']) && file_exists('uploads/' . $img['image'])) {
                unlink('uploads/' . $img['image']);
            }
            // ลบข้อมูลอุปกรณ์ออกจากฐานข้อมูล
            $d = $conn->prepare("DELETE FROM items WHERE item_id = ?");
            $d->bind_param("i", $item_id);
            try {
                $d->execute();
                header("Location: admin_items.php?ok=deleted");
                exit();
            } catch (Exception $e) {
                // ถ้ามีประวัติการยืมเก่าผูกอยู่ (foreign key) จะลบไม่ได้ -> แจ้งข้อผิดพลาด
                $msg_err = "ลบไม่ได้ เพราะมีประวัติการยืมของอุปกรณ์นี้อยู่ในระบบ";
            }
        }
    }
}

// ---- แสดงข้อความสำเร็จหลัง redirect (อ่านจาก ?ok=...) ----
if (isset($_GET['ok'])) {
    // แปลงรหัสผลลัพธ์เป็นข้อความภาษาไทย
    $labels = ['added' => 'เพิ่มอุปกรณ์แล้ว', 'qty' => 'ปรับจำนวนเรียบร้อย', 'deleted' => 'ลบอุปกรณ์แล้ว'];
    $msg_ok = $labels[$_GET['ok']] ?? '';
}

// ดึงรายการอุปกรณ์ทั้งหมด เรียงจากใหม่ไปเก่า เพื่อนำไปแสดงในตาราง
$items = $conn->query("SELECT * FROM items ORDER BY item_id DESC");
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการอุปกรณ์ (แอดมิน)</title>
    <!-- ไฟล์ CSS หลัก และ CSS เฉพาะส่วนปรับจำนวน -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>
<body class="bg-page">
<div class="container">

    <!-- หัวข้อหน้า -->
    <h1 class="page-title">⚙️ เพิ่ม / ปรับจำนวน / ลบ อุปกรณ์ (แอดมิน)</h1>

    <!-- กล่องแจ้งผล: แสดงเมื่อสำเร็จ (สีเขียว) หรือผิดพลาด (สีแดง)
         htmlspecialchars ป้องกัน XSS -->
    <?php if ($msg_ok): ?><div class="flash flash-success"><?= htmlspecialchars($msg_ok) ?></div><?php endif; ?>
    <?php if ($msg_err): ?><div class="flash flash-error"><?= htmlspecialchars($msg_err) ?></div><?php endif; ?>

    <!-- ============ ฟอร์มเพิ่มอุปกรณ์ใหม่ ============ -->
    <div class="card card-padded">
        <h2 class="card-title">เพิ่มรายการอุปกรณ์ใหม่</h2>

        <!-- enctype="multipart/form-data" จำเป็นสำหรับการอัปโหลดไฟล์ -->
        <form method="POST" enctype="multipart/form-data" class="form-grid">
            <!-- บอกฝั่ง PHP ว่าเป็นการ "เพิ่ม" -->
            <input type="hidden" name="action" value="add">

            <div>
                <label class="form-label">รหัสอุปกรณ์</label>
                <input type="text" name="item_code" required placeholder="เช่น SPT-003" class="form-input">
            </div>
            <div>
                <label class="form-label">ชื่ออุปกรณ์</label>
                <input type="text" name="item_name" required placeholder="เช่น ลูกบาสเกตบอล" class="form-input">
            </div>
            <div>
                <label class="form-label">หมวดหมู่</label>
                <!-- เลือกหมวดหมู่: กีฬา / บอร์ดเกม -->
                <select name="category" class="form-select">
                    <option value="sports">อุปกรณ์กีฬา</option>
                    <option value="boardgame">บอร์ดเกม</option>
                </select>
            </div>
            <div>
                <label class="form-label">จำนวน (ชิ้น)</label>
                <input type="number" name="total_qty" min="1" value="1" required class="form-input">
            </div>
            <div>
                <label class="form-label">รูปภาพอุปกรณ์</label>
                <!-- เลือกไฟล์รูป (ไม่บังคับ) -->
                <input type="file" name="image" accept="image/*" class="form-file">
            </div>
            <div class="form-field-wide">
                <button type="submit" class="btn btn-primary">+ บันทึกอุปกรณ์</button>
            </div>
        </form>
    </div>

    <!-- ============ ตารางแสดงรายการอุปกรณ์ ============ -->
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>รูป</th>
                    <th>รหัส</th>
                    <th>ชื่ออุปกรณ์</th>
                    <th>หมวดหมู่</th>
                    <th>คงเหลือ / ถูกยืม</th>
                    <th>ปรับจำนวนทั้งหมด</th>
                    <th>สถานะ</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <!-- วนลูปแสดงอุปกรณ์ทีละแถว -->
                <?php while($row = $items->fetch_assoc()): ?>
                <?php
                    // คำนวณตัวเลขที่ใช้แสดงผล
                    $total = (int)$row['total_qty'];      // จำนวนทั้งหมด
                    $avail = (int)$row['available_qty'];  // จำนวนคงเหลือ
                    $borrowed = $total - $avail;          // จำนวนที่ถูกยืม
                ?>
                <tr>
                    <!-- คอลัมน์รูป: ถ้ามีรูปแสดงรูป ถ้าไม่มีแสดงกล่อง "ไม่มีรูป" -->
                    <td>
                        <?php if (!empty($row['image']) && file_exists('uploads/' . $row['image'])): ?>
                            <img src="uploads/<?= htmlspecialchars($row['image']) ?>" class="thumb">
                        <?php else: ?>
                            <div class="thumb-empty">ไม่มีรูป</div>
                        <?php endif; ?>
                    </td>
                    <td class="cell-code"><?= htmlspecialchars($row['item_code']) ?></td>
                    <td class="cell-name"><?= htmlspecialchars($row['item_name']) ?></td>
                    <!-- แสดงหมวดหมู่เป็นข้อความพร้อมไอคอน -->
                    <td class="cell-muted"><?= $row['category'] == 'sports' ? '⚽ กีฬา' : '🎲 บอร์ดเกม' ?></td>
                    <!-- แสดง คงเหลือ / ทั้งหมด และจำนวนที่ถูกยืม -->
                    <td>
                        <span class="qty-badge"><?= $avail ?> / <?= $total ?></span>
                        <div class="cell-muted" style="font-size:.75rem">ถูกยืม <?= $borrowed ?> ชิ้น</div>
                    </td>
                    <!-- ฟอร์มปรับจำนวนทั้งหมด: ช่องกรอกมีค่าต่ำสุด = จำนวนที่ถูกยืมอยู่ -->
                    <td>
                        <form method="POST" class="qty-form">
                            <input type="hidden" name="action" value="set_qty">
                            <input type="hidden" name="item_id" value="<?= $row['item_id'] ?>">
                            <input type="number" name="total_qty" min="<?= $borrowed ?>" value="<?= $total ?>" required>
                            <button type="submit" class="btn-small">บันทึก</button>
                        </form>
                    </td>
                    <!-- ป้ายสถานะ: ว่าง (ยังมีของเหลือ) / ถูกยืมหมด -->
                    <td>
                        <span class="badge <?= $avail > 0 ? 'badge-available' : 'badge-borrowed' ?>">
                            <?= $avail > 0 ? 'ว่าง' : 'ถูกยืมหมด' ?>
                        </span>
                    </td>
                    <!-- ปุ่มลบ: มีหน้าต่างยืนยันก่อนส่งฟอร์ม -->
                    <td>
                        <form method="POST" onsubmit="return confirm('ยืนยันการลบ?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="item_id" value="<?= $row['item_id'] ?>">
                            <button type="submit" class="btn-del">ลบ</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>