<?php
// ===== ส่วนที่ 1: เตรียมระบบ =====

// ดึงไฟล์เชื่อมต่อฐานข้อมูลมาใช้ (ได้ตัวแปร $conn สำหรับสั่งงาน database)
require_once 'db.php';

// ดึงแถบเมนูด้านบน (navbar) มาแสดง
// ไฟล์นี้น่าจะมี session_start() อยู่ข้างใน จึงใช้ $_SESSION ได้ต่อ
require_once 'navbar.php';

// ===== ส่วนที่ 2: ตรวจสอบสิทธิ์ =====

// ถ้าคนที่ล็อกอินอยู่ไม่ใช่แอดมิน ให้หยุดทำงานทันทีและแสดงข้อความ "สำหรับแอดมินเท่านั้น"
// die() = แสดงข้อความแล้วหยุดโค้ดทั้งหมด คนทั่วไปจะไม่เห็นข้อมูลด้านล่าง
if ($_SESSION['role'] !== 'admin') {
    die("<div class='msg-error-page'>สำหรับแอดมินเท่านั้น</div>");
}

// ===== ส่วนที่ 3: ดึงข้อมูลจากฐานข้อมูล =====

// คำสั่ง SQL ดึงรายการยืมทั้งหมด โดยรวมข้อมูลจาก 3 ตาราง
//   loans  = ตารางการยืม (l)
//   users  = ตารางผู้ใช้ (u) เอาชื่อกับรหัสนักศึกษา
//   items  = ตารางอุปกรณ์ (i) เอารหัสกับชื่ออุปกรณ์
// JOIN = เชื่อมตารางเข้าด้วยกันผ่านรหัสที่ตรงกัน (user_id, item_id)
// ORDER BY loan_id DESC = เรียงจากรายการล่าสุดไปเก่าสุด
$sql = "SELECT l.*, u.name as user_name, u.student_id, i.item_code, i.item_name
        FROM loans l
        JOIN users u ON l.user_id = u.user_id
        JOIN items i ON l.item_id = i.item_id
        ORDER BY l.loan_id DESC";

// สั่งให้ฐานข้อมูลทำงานตาม SQL แล้วเก็บผลลัพธ์ไว้ใน $loans
$loans = $conn->query($sql);

// เก็บเวลาปัจจุบันไว้ เพื่อใช้เทียบว่าใครคืนช้าเกินกำหนดหรือยัง
$now = date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8"> <!-- รองรับภาษาไทย -->
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- ให้แสดงผลพอดีบนมือถือ -->
    <title>รายการยืมทั้งหมด (แอดมิน)</title>
    <link rel="stylesheet" href="style.css">     <!-- ไฟล์ตกแต่งหลัก -->
    <link rel="stylesheet" href="style_qty.css"> <!-- ไฟล์ตกแต่งป้ายจำนวน -->
</head>
<body class="bg-page">
<div class="container">
    <h1 class="page-title">📊 รายการยืมทั้งหมดในระบบ (แอดมิน)</h1>

    <div class="table-wrap">
        <table class="data-table">
            <!-- ===== หัวตาราง ===== -->
            <thead>
                <tr>
                    <th>ผู้ยืม</th>
                    <th>อุปกรณ์</th>
                    <th>จำนวน</th>
                    <th>วันที่ยืม</th>
                    <th>กำหนดคืน</th>
                    <th>วันที่คืนจริง</th>
                    <th>สถานะ</th>
                </tr>
            </thead>

            <tbody>
                <?php
                // วนลูปดึงข้อมูลทีละแถวจากผลลัพธ์ ($row = ข้อมูลการยืม 1 รายการ)
                // วนไปเรื่อยๆ จนหมดทุกรายการ
                while($row = $loans->fetch_assoc()):
                ?>

                <?php
                // ตรวจว่า "เกินกำหนด" หรือไม่ ต้องครบ 2 เงื่อนไข:
                //   1) สถานะยังเป็น active (ยังไม่คืนของ)
                //   2) เวลาปัจจุบันเลยกำหนดคืนไปแล้ว
                // ผลลัพธ์เป็น true/false เก็บใน $is_overdue
                $is_overdue = ($row['status'] === 'active' && $now > $row['due_date']);
                ?>

                <!-- ถ้าเกินกำหนดจะใส่ class 'row-overdue' เพื่อทำให้แถวเป็นสีเตือน -->
                <tr class="<?= $is_overdue ? 'row-overdue' : '' ?>">

                    <!-- คอลัมน์ผู้ยืม: ชื่อ + (รหัสนักศึกษา) -->
                    <!-- htmlspecialchars() ป้องกันคนแอบใส่โค้ดอันตรายเข้ามา (XSS) -->
                    <td>
                        <?= htmlspecialchars($row['user_name']) ?>
                        (<?= htmlspecialchars($row['student_id']) ?>)
                    </td>

                    <!-- คอลัมน์อุปกรณ์: [รหัส] ชื่ออุปกรณ์ -->
                    <td>
                        [<?= htmlspecialchars($row['item_code']) ?>]
                        <?= htmlspecialchars($row['item_name']) ?>
                    </td>

                    <!-- คอลัมน์จำนวน: แสดงเป็นป้าย เช่น × 2 -->
                    <!-- (int) = แปลงให้เป็นตัวเลขเสมอ เพื่อความปลอดภัย -->
                    <td><span class="qty-badge">× <?= (int)$row['quantity'] ?></span></td>

                    <!-- คอลัมน์วันที่ยืม -->
                    <td><?= $row['borrow_date'] ?></td>

                    <!-- คอลัมน์กำหนดคืน: จัดรูปแบบเป็น วัน/เดือน/ปี ชั่วโมง:นาที -->
                    <!-- ถ้าเกินกำหนด จะเปลี่ยนสีและมีป้าย "⚠️ เกินกำหนด" ต่อท้าย -->
                    <td class="cell-due <?= $is_overdue ? 'is-overdue' : '' ?>">
                        <?= date('d/m/Y H:i', strtotime($row['due_date'])) ?>
                        <?= $is_overdue ? '<span class="badge-overdue">⚠️ เกินกำหนด</span>' : '' ?>
                    </td>

                    <!-- คอลัมน์วันที่คืนจริง: ถ้ายังไม่คืน (ค่าว่าง) ให้แสดงเครื่องหมาย - -->
                    <td><?= $row['return_date'] ?: '-' ?></td>

                    <!-- คอลัมน์สถานะ: active = "ยังไม่คืน", อย่างอื่น = "คืนแล้ว" -->
                    <td>
                        <?= $row['status'] == 'active'
                            ? '<span class="text-pending">ยังไม่คืน</span>'
                            : '<span class="text-done">คืนแล้ว</span>' ?>
                    </td>
                </tr>
                <?php endwhile; // จบการวนลูป ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>




<!--
1. เชื่อมต่อฐานข้อมูลและเรียกใช้แถบเมนู
2. ตรวจสอบสิทธิ์การเข้าใช้งาน โดยอนุญาตเฉพาะแอดมิน
3. ดึงรายการยืมทั้งหมดจากฐานข้อมูล พร้อมข้อมูลผู้ยืมและอุปกรณ์
4. แสดงชื่อผู้ยืม รหัสนักศึกษา ชื่ออุปกรณ์ และจำนวนที่ยืม
5. แสดงวันที่ยืม กำหนดคืน และวันที่คืนจริง
6. ตรวจสอบว่ารายการใดเกินกำหนดคืน
7. แสดงสีและข้อความแจ้งเตือนสำหรับรายการที่เกินกำหนด
8. แสดงสถานะว่าอุปกรณ์ยังไม่คืนหรือคืนแล้ว

โดยรวมไฟล์นี้ทำหน้าที่ให้แอดมินตรวจสอบรายการยืมทั้งหมด
ติดตามการคืนอุปกรณ์ และตรวจสอบรายการที่เกินกำหนดคืน
-->
