
<?php
// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db.php';

// เรียกใช้ไฟล์แถบเมนูของเว็บไซต์
require_once 'navbar.php';

// เก็บ ID ของผู้ใช้ที่เข้าสู่ระบบอยู่
$user_id = $_SESSION['user_id'];

// คำสั่ง SQL สำหรับดึงประวัติการยืมของผู้ใช้
$sql = "SELECT l.*, i.item_code, i.item_name, i.image
        FROM loans l
        JOIN items i ON l.item_id = i.item_id
        WHERE l.user_id = ?
        ORDER BY l.loan_id DESC";

// เตรียมคำสั่ง SQL เพื่อรับข้อมูลผู้ใช้
$stmt = $conn->prepare($sql);

// ใส่ ID ผู้ใช้ลงในเครื่องหมาย ?
// i หมายถึงข้อมูลชนิดจำนวนเต็ม
$stmt->bind_param("i", $user_id);

// สั่งให้ฐานข้อมูลค้นหาประวัติการยืม
$stmt->execute();

// เก็บผลลัพธ์ที่ค้นหาได้
$result = $stmt->get_result();

// เก็บวันและเวลาปัจจุบัน
// ใช้ตรวจสอบว่าอุปกรณ์เกินกำหนดคืนหรือไม่
$now = date('Y-m-d H:i:s');
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <!-- กำหนดให้รองรับภาษาไทย -->
    <meta charset="UTF-8">

    <!-- ทำให้หน้าเว็บปรับขนาดตามหน้าจออุปกรณ์ -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ชื่อหน้าเว็บที่แสดงบนแท็บเบราว์เซอร์ -->
    <title>ประวัติการยืม</title>

    <!-- เรียกใช้ไฟล์ CSS สำหรับตกแต่งเว็บไซต์ -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>

<!-- กำหนดคลาสสำหรับตกแต่งพื้นหลังหน้าเว็บ -->
<body class="bg-page">

<div class="container">

    <!-- หัวข้อหลักของหน้าเว็บ -->
    <h1 class="page-title">📋 ประวัติการยืมของคุณ</h1>

    <!-- กรอบสำหรับแสดงตาราง -->
    <div class="table-wrap">

        <!-- ตารางแสดงประวัติการยืม -->
        <table class="data-table">

            <!-- ส่วนหัวตาราง -->
            <thead>
                <tr>
                    <th>รูป</th>
                    <th>รหัส</th>
                    <th>อุปกรณ์</th>
                    <th>จำนวน</th>
                    <th>วันที่ยืม</th>
                    <th>กำหนดคืน</th>
                    <th>วันที่คืนจริง</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>

            <!-- ส่วนแสดงข้อมูลในตาราง -->
            <tbody>

                <?php
                // วนอ่านข้อมูลทีละรายการจนกว่าจะครบทุกประวัติ
                while($row = $result->fetch_assoc()):
                ?>

                <?php
                // ตรวจสอบว่าเลยกำหนดคืนหรือยัง
                // ต้องเป็นรายการที่ยังไม่คืน (active)
                // และเวลาปัจจุบันต้องมากกว่ากำหนดคืน
                $is_overdue = (
                    $row['status'] === 'active'
                    && $now > $row['due_date']
                );
                ?>

                <!-- ถ้าเกินกำหนด จะเพิ่มคลาส row-overdue ให้แถวนี้ -->
                <tr class="<?= $is_overdue ? 'row-overdue' : '' ?>">

                    <!-- แสดงรูปอุปกรณ์ -->
                    <td>
                        <?php
                        // ตรวจว่ามีชื่อรูปและไฟล์รูปอยู่จริงหรือไม่
                        if (!empty($row['image']) &&
                            file_exists('uploads/' . $row['image'])):
                        ?>

                            <!-- แสดงรูปอุปกรณ์ -->
                            <img
                                src="uploads/<?= htmlspecialchars($row['image']) ?>"
                                class="thumb"
                            >

                        <?php else: ?>

                            <!-- ถ้าไม่มีรูป ให้แสดงข้อความนี้ -->
                            <div class="thumb-empty">ไม่มีรูป</div>

                        <?php endif; ?>
                    </td>

                    <!-- แสดงรหัสอุปกรณ์ -->
                    <!-- htmlspecialchars() ช่วยป้องกันการแสดง HTML ที่ไม่ต้องการ -->
                    <td class="cell-code">
                        <?= htmlspecialchars($row['item_code']) ?>
                    </td>

                    <!-- แสดงชื่ออุปกรณ์ -->
                    <td class="cell-name">
                        <?= htmlspecialchars($row['item_name']) ?>
                    </td>

                    <!-- แสดงจำนวนอุปกรณ์ที่ยืม -->
                    <!-- (int) แปลงค่าให้เป็นจำนวนเต็ม -->
                    <td>
                        <span class="qty-badge">
                            × <?= (int)$row['quantity'] ?>
                        </span>
                    </td>

                    <!-- แสดงวันที่ยืม -->
                    <td class="cell-muted">
                        <?= $row['borrow_date'] ?>
                    </td>

                    <!-- แสดงวันและเวลาที่ต้องคืน -->
                    <!-- ถ้าเกินกำหนด จะเพิ่มรูปแบบ is-overdue -->
                    <td class="cell-due <?= $is_overdue ? 'is-overdue' : '' ?>">

                        <!-- แปลงวันที่เป็น วัน/เดือน/ปี ชั่วโมง:นาที -->
                        <?= date('d/m/Y H:i', strtotime($row['due_date'])) ?>

                        <?php
                        // ถ้าเกินกำหนด ให้แสดงป้ายแจ้งเตือน
                        if ($is_overdue):
                        ?>
                            <span class="badge-overdue">เกินกำหนด</span>
                        <?php endif; ?>

                    </td>

                    <!-- แสดงวันที่คืนจริง -->
                    <!-- ถ้ายังไม่มีวันที่คืน ให้แสดงเครื่องหมาย - -->
                    <td class="cell-muted">
                        <?= $row['return_date'] ?: '-' ?>
                    </td>

                    <!-- ส่วนจัดการการคืนอุปกรณ์ -->
                    <td>

                        <?php
                        // ตรวจสอบว่ายังไม่ได้คืนอุปกรณ์หรือไม่
                        if ($row['status'] == 'active'):
                        ?>

                            <!-- แสดงปุ่มคืนอุปกรณ์ พร้อมหน้าต่างยืนยัน -->
                            <a
                                href="return.php?loan_id=<?= $row['loan_id'] ?>"
                                class="btn-return"
                                onclick="return confirm('ยืนยันนำของมาคืนแล้ว?')"
                            >
                                คืนอุปกรณ์
                            </a>

                        <?php else: ?>

                            <!-- ถ้าคืนแล้ว ให้แสดงสถานะว่าคืนเรียบร้อย -->
                            <span class="badge badge-returned">
                                คืนเรียบร้อย
                            </span>

                        <?php endif; ?>

                    </td>

                </tr>

                <!-- จบการวนแสดงข้อมูลแต่ละรายการ -->
                <?php endwhile; ?>

            </tbody>
        </table>
    </div>
</div>

</body>
</html>

<!-- โดยรวมหน้านี้ใช้แสดงประวัติการยืมอุปกรณ์ของผู้ใช้ที่เข้าสู่ระบบ
     แสดงรูป รหัส ชื่อ จำนวน วันที่ยืม และวันกำหนดคืน
     ตรวจสอบและแจ้งเตือนเมื่ออุปกรณ์เกินกำหนดคืน
     แสดงวันที่คืนจริง และปุ่มคืนอุปกรณ์สำหรับรายการที่ยังไม่ได้คืน
     เมื่อคืนแล้วจะแสดงสถานะคืนเรียบร้อย -->
