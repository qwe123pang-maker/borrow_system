<?php
// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล และไฟล์เมนูนำทาง
require_once 'db.php';
require_once 'navbar.php';

// รับคำค้นหาจาก URL หากไม่มีคำค้นหา ให้กำหนดเป็นค่าว่าง
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// ค้นหาอุปกรณ์จากชื่อหรือรหัส และเรียงรายการใหม่ไปเก่า
$sql = "SELECT * FROM items WHERE item_name LIKE ? OR item_code LIKE ? ORDER BY item_id DESC";
$stmt = $conn->prepare($sql);
$param = "%$search%";
$stmt->bind_param("ss", $param, $param);
$stmt->execute();
$result = $stmt->get_result();

// รับข้อความแจ้งข้อผิดพลาดจาก Session หากมี
$flash_error = $_SESSION['flash_error'] ?? '';

// ลบข้อความแจ้งเตือนออกจาก Session หลังจากนำมาใช้งาน
unset($_SESSION['flash_error']);

// กำหนดช่วงวันและเวลาที่ผู้ใช้สามารถเลือกคืนอุปกรณ์ได้
// เลือกได้ตั้งแต่เวลาปัจจุบันจนถึงอีก 7 วัน
$min_dt     = date('Y-m-d\TH:i');
$max_dt     = date('Y-m-d\TH:i', strtotime('+7 days'));

// กำหนดวันและเวลาคืนเริ่มต้นเป็นอีก 7 วัน
$default_dt = $max_dt;
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>รายการอุปกรณ์</title>

    <!-- เรียกใช้ไฟล์ CSS สำหรับตกแต่งหน้าเว็บ -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>
<body class="bg-page">
<div class="container">
    <div class="toolbar">
        <div>
            <!-- แสดงหัวข้อและคำอธิบายของหน้า -->
            <h1 class="page-title">📦 รายการอุปกรณ์กีฬา และ บอร์ดเกม</h1>
            <p class="page-subtitle">เลือกอุปกรณ์ จำนวน และกำหนดวันเวลาคืน (ไม่เกิน 7 วัน)</p>
        </div>

        <!-- แบบฟอร์มค้นหาอุปกรณ์ด้วยชื่อหรือรหัส -->
        <form method="GET" class="search-form">
            <input type="text" name="search" placeholder="ค้นหาชื่อหรือรหัส..." value="<?= htmlspecialchars($search) ?>" class="search-input">
            <button type="submit" class="btn-search">ค้นหา</button>
        </form>
    </div>

    <!-- แสดงข้อความแจ้งข้อผิดพลาด หากมี -->
    <?php if ($flash_error): ?>
        <div class="flash flash-error"><?= htmlspecialchars($flash_error) ?></div>
    <?php endif; ?>

    <!-- แสดงรายการอุปกรณ์ในรูปแบบการ์ด -->
    <div class="item-grid">
        <!-- วนลูปแสดงข้อมูลอุปกรณ์แต่ละรายการ -->
        <?php while($row = $result->fetch_assoc()): ?>

            <?php
            // แปลงจำนวนอุปกรณ์ที่เหลือให้เป็นตัวเลขจำนวนเต็ม
            $avail = (int)$row['available_qty'];
            ?>

            <div class="item-card">
                <div class="item-image">

                    <!-- ตรวจสอบว่ามีรูปภาพและไฟล์รูปภาพอยู่จริงหรือไม่ -->
                    <?php if (!empty($row['image']) && file_exists('uploads/' . $row['image'])): ?>
                        <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="">
                    <?php else: ?>
                        <!-- แสดงข้อความเมื่อไม่มีรูปภาพ -->
                        <div class="item-noimage">
                            <span>📷</span>
                            <p>ไม่มีรูปภาพ</p>
                        </div>
                    <?php endif; ?>

                    <!-- แสดงสถานะตามจำนวนอุปกรณ์ที่เหลือ -->
                    <span class="item-status <?= $avail > 0 ? 'available' : 'borrowed' ?>">
                        <?= $avail > 0 ? 'พร้อมยืม' : 'ถูกยืมหมดแล้ว' ?>
                    </span>
                </div>

                <div class="item-body">
                    <div>
                        <!-- แสดงรหัสและประเภทอุปกรณ์ -->
                        <div class="item-meta">
                            <span class="item-code"><?= htmlspecialchars($row['item_code']) ?></span>
                            <span class="item-category"><?= $row['category'] == 'sports' ? '⚽ กีฬา' : '🎲 บอร์ดเกม' ?></span>
                        </div>

                        <!-- แสดงชื่ออุปกรณ์ -->
                        <h3 class="item-name"><?= htmlspecialchars($row['item_name']) ?></h3>

                        <!-- แสดงจำนวนอุปกรณ์ที่เหลือและจำนวนทั้งหมด -->
                        <p class="stock-info">คงเหลือ <b><?= $avail ?></b> / <?= (int)$row['total_qty'] ?> ชิ้น</p>
                    </div>

                    <div>
                        <!-- หากยังมีอุปกรณ์เหลือ ให้แสดงแบบฟอร์มยืม -->
                        <?php if ($avail > 0): ?>
                            <form method="POST" action="borrow.php" class="borrow-form"
                                  onsubmit="return confirm('ยืนยันการทำรายการยืม?')">

                                <!-- ส่งรหัสอุปกรณ์ไปยังไฟล์ borrow.php -->
                                <input type="hidden" name="item_id" value="<?= (int)$row['item_id'] ?>">

                                <!-- ให้ผู้ใช้ระบุจำนวนที่ต้องการยืม -->
                                <div>
                                    <label>จำนวนที่ต้องการยืม</label>
                                    <input type="number" name="quantity" min="1" max="<?= $avail ?>" value="1" required>
                                </div>

                                <!-- ให้ผู้ใช้เลือกวันและเวลาที่ต้องการคืน -->
                                <div>
                                    <label>วันและเวลาคืน</label>
                                    <input type="datetime-local" name="due_datetime"
                                           min="<?= $min_dt ?>" max="<?= $max_dt ?>"
                                           value="<?= $default_dt ?>" required>
                                    <span class="hint">เลือกได้ไม่เกิน 7 วันนับจากตอนนี้</span>
                                </div>

                                <!-- ส่งข้อมูลการยืมไปประมวลผลที่ borrow.php -->
                                <button type="submit" class="btn-borrow">ยืมอุปกรณ์นี้</button>
                            </form>
                        <?php else: ?>
                            <!-- หากไม่มีอุปกรณ์เหลือ ให้ปิดการใช้งานปุ่มยืม -->
                            <button disabled class="btn-disabled">ไม่พร้อมบริการ</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>

<!-- โดยรวมหน้านี้ใช้แสดงรายการอุปกรณ์กีฬาและบอร์ดเกมจากฐานข้อมูล
     ผู้ใช้สามารถค้นหาอุปกรณ์ ดูรูปภาพ ประเภท และจำนวนคงเหลือ
     เลือกจำนวนที่ต้องการยืม และกำหนดวันเวลาคืนได้ภายใน 7 วัน
     หากอุปกรณ์หมด ระบบจะแสดงว่าไม่พร้อมบริการ
     เมื่อยืนยันการยืม ระบบจะส่งข้อมูลไปยังไฟล์ borrow.php
     เพื่อประมวลผลการยืมและบันทึกข้อมูลลงฐานข้อมูล -->

