<?php
// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db.php';

// กำหนดตัวแปรสำหรับเก็บข้อความแจ้งข้อผิดพลาด
$error = '';
 
// ตรวจสอบว่าผู้ใช้ส่งข้อมูลผ่านแบบฟอร์มด้วยวิธี POST หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // รับรหัสนักศึกษาและรหัสผ่าน พร้อมตัดช่องว่างหัวท้าย
    $student_id = trim($_POST['student_id']);
    $password = trim($_POST['password']);
 
    // ค้นหาข้อมูลผู้ใช้จากรหัสนักศึกษา
    $stmt = $conn->prepare("SELECT * FROM users WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();

    // รับผลลัพธ์และดึงข้อมูลผู้ใช้มาเก็บไว้
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
 
    // ตรวจสอบว่ามีผู้ใช้หรือไม่ และรหัสผ่านถูกต้องหรือไม่
    // รองรับทั้งรหัสผ่านแบบเข้ารหัสและรหัสผ่านแบบข้อความธรรมดา
    $valid = $user && (password_verify($password, $user['password']) || hash_equals($user['password'], $password));
 
    // หากข้อมูลเข้าสู่ระบบถูกต้อง
    if ($valid) {

        // บันทึกรหัสผู้ใช้ ชื่อ และสิทธิ์ลงใน Session
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        // เข้าสู่หน้าหลักของระบบ
        header("Location: index.php");
        exit();
    } else {

        // แสดงข้อความเมื่อรหัสผู้ใช้หรือรหัสผ่านไม่ถูกต้อง
        $error = "รหัสผู้ใช้ หรือรหัสผ่านไม่ถูกต้อง!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>เข้าสู่ระบบ - สโมสรนักศึกษา</title>

    <!-- เรียกใช้ไฟล์ CSS สำหรับตกแต่งหน้าเว็บ -->
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">
    <div class="auth-card">
        <div class="auth-header">

            <!-- แสดงไอคอนและชื่อระบบ -->
            <div class="auth-icon">⚽</div>
            <h1 class="auth-title">ระบบยืม-คืนอุปกรณ์</h1>
            <p class="auth-subtitle">สโมสรนักศึกษา</p>
        </div>
 
        <!-- แสดงข้อความแจ้งข้อผิดพลาด หากเข้าสู่ระบบไม่สำเร็จ -->
        <?php if($error): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
 
        <!-- แบบฟอร์มกรอกรหัสนักศึกษาและรหัสผ่าน -->
        <form method="POST" class="form-stack">
            <div>
                <label class="auth-label">รหัสนักศึกษา / แอดมิน</label>
                <input type="text" name="student_id" required class="auth-input" placeholder="เช่น 66000001 หรือ admin">
            </div>
            <div>
                <label class="auth-label">รหัสผ่าน</label>
                <input type="password" name="password" required class="auth-input" placeholder="1234">
            </div>

            <!-- ปุ่มส่งข้อมูลเพื่อตรวจสอบการเข้าสู่ระบบ -->
            <button type="submit" class="btn-auth">เข้าสู่ระบบ</button>
        </form>
 
        <!-- ลิงก์ไปยังหน้าสมัครสมาชิก -->
        <p class="auth-footer">
            ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a>
        </p>
 
        <!-- แสดงบัญชีตัวอย่างสำหรับทดสอบระบบ -->
        <div class="test-box">
            <p class="test-box-title">บัญชีสำหรับทดสอบ:</p>
            <p>• นักศึกษา: <code>66000001</code> / รหัสผ่าน <code>1234</code></p>
            <p>• แอดมิน: <code>admin</code> / รหัสผ่าน <code>1234</code></p>
        </div>
    </div>
</body>
</html>

<!-- โดยรวมหน้านี้ใช้สำหรับเข้าสู่ระบบยืม-คืนอุปกรณ์
     ผู้ใช้กรอกรหัสนักศึกษาหรือบัญชีแอดมินและรหัสผ่าน
     ระบบจะตรวจสอบข้อมูลกับฐานข้อมูล หากถูกต้องจะบันทึกข้อมูลผู้ใช้ลง Session
     แล้วนำไปยังหน้าหลัก แต่หากข้อมูลไม่ถูกต้องจะแสดงข้อความแจ้งเตือน
     นอกจากนี้ยังมีลิงก์สมัครสมาชิกและบัญชีตัวอย่างสำหรับทดสอบระบบ -->

