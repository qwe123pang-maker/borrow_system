<?php
// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบแล้วหรือไม่
// หากยังไม่ได้เข้าสู่ระบบ ให้กลับไปหน้า login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!-- เรียกใช้ไฟล์ CSS สำหรับตกแต่งหน้าเว็บ -->
<link rel="stylesheet" href="style.css">

<!-- สร้างแถบเมนูนำทางของเว็บไซต์ -->
<nav class="navbar">
    <div class="navbar-inner">
        <div class="navbar-left">

            <!-- โลโก้และชื่อสโมสรนักศึกษา -->
            <a href="index.php" class="navbar-brand">
                <span>⚽</span>
                <span>สโมสรนักศึกษา</span>
            </a>

            <!-- ลิงก์ไปยังหน้ารายการอุปกรณ์ -->
            <a href="index.php" class="nav-link">รายการอุปกรณ์</a>

            <!-- ลิงก์ไปยังหน้าประวัติการยืม -->
            <a href="history.php" class="nav-link">ประวัติการยืม</a>

            <!-- แสดงเมนูจัดการสำหรับผู้ใช้ที่มีสิทธิ์แอดมินเท่านั้น -->
            <?php if ($_SESSION['role'] === 'admin'): ?>

                <!-- ลิงก์ไปยังหน้าจัดการอุปกรณ์ -->
                <a href="admin_items.php" class="nav-admin">⚙️ [แอดมิน] จัดการอุปกรณ์</a>

                <!-- ลิงก์ไปยังหน้าดูรายการยืมทั้งหมด -->
                <a href="admin_loans.php" class="nav-admin">📊 [แอดมิน] การยืมทั้งหมด</a>

            <?php endif; ?>
        </div>

        <div class="navbar-right">

            <!-- แสดงชื่อผู้ใช้ที่เข้าสู่ระบบ -->
            <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['name']) ?></span>

            <!-- ลิงก์สำหรับออกจากระบบ -->
            <a href="logout.php" class="btn-logout">ออกจากระบบ</a>
        </div>
    </div>
</nav>

<!-- โดยรวมไฟล์นี้ใช้สร้างแถบเมนูนำทางของระบบยืม-คืนอุปกรณ์
     ตรวจสอบว่าผู้ใช้เข้าสู่ระบบแล้วหรือไม่
     แสดงเมนูรายการอุปกรณ์ ประวัติการยืม ชื่อผู้ใช้ และปุ่มออกจากระบบ
     หากเป็นแอดมิน จะแสดงเมนูจัดการอุปกรณ์และดูรายการยืมทั้งหมดเพิ่มเติม -->

