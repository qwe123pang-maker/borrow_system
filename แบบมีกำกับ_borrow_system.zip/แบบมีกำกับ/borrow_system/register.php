<?php
// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db.php';

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบอยู่แล้วหรือไม่
// หากเข้าสู่ระบบแล้ว ให้กลับไปหน้ารายการอุปกรณ์
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// กำหนดตัวแปรสำหรับเก็บข้อความแจ้งข้อผิดพลาดและข้อความสำเร็จ
$error = '';
$success = '';

// กำหนดตัวแปรสำหรับเก็บรหัสนักศึกษาและชื่อ
$name = '';
$student_id = '';

// ตรวจสอบว่าผู้ใช้ส่งข้อมูลผ่านแบบฟอร์มด้วยวิธี POST หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // รับข้อมูลจากแบบฟอร์มและตัดช่องว่างหัวท้าย
    $student_id = trim($_POST['student_id'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    // ตรวจสอบว่ากรอกข้อมูลที่จำเป็นครบหรือไม่
    if ($student_id === '' || $name === '' || $password === '') {
        $error = "กรุณากรอกข้อมูลให้ครบทุกช่อง";

    // ตรวจสอบว่ารหัสนักศึกษาเป็นตัวอักษร ตัวเลข หรือ _ จำนวน 3-20 ตัวหรือไม่
    } elseif (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $student_id)) {
        $error = "รหัสนักศึกษาต้องเป็นตัวอักษร/ตัวเลข 3-20 ตัว";

    // ตรวจสอบว่าชื่อมีความยาวไม่เกิน 100 ตัวอักษรหรือไม่
    } elseif (mb_strlen($name) > 100) {
        $error = "ชื่อยาวเกินไป";

    // ตรวจสอบว่ารหัสผ่านมีความยาวอย่างน้อย 4 ตัวอักษรหรือไม่
    } elseif (strlen($password) < 4) {
        $error = "รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร";

    // ตรวจสอบว่ารหัสผ่านและการยืนยันรหัสผ่านตรงกันหรือไม่
    } elseif ($password !== $confirm) {
        $error = "รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน";

    } else {
        // ค้นหารหัสนักศึกษาในฐานข้อมูลเพื่อป้องกันการสมัครซ้ำ
        $chk = $conn->prepare("SELECT user_id FROM users WHERE student_id = ?");
        $chk->bind_param("s", $student_id);
        $chk->execute();

        // หากพบรหัสนักศึกษานี้แล้ว ให้แจ้งเตือน
        if ($chk->get_result()->num_rows > 0) {
            $error = "รหัสนี้ถูกใช้งานแล้ว";

        } else {
            // เข้ารหัสผ่านก่อนบันทึกลงฐานข้อมูล
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // กำหนดสิทธิ์เริ่มต้นเป็นนักศึกษา
            // ผู้สมัครไม่สามารถกำหนดสิทธิ์แอดมินเองได้
            $role = 'student';

            // เตรียมคำสั่งเพิ่มข้อมูลสมาชิกลงในตาราง users
            $stmt = $conn->prepare("INSERT INTO users (student_id, name, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $student_id, $name, $hash, $role);

            // ตรวจสอบว่าบันทึกข้อมูลสมาชิกสำเร็จหรือไม่
            if ($stmt->execute()) {
                $success = "สมัครสมาชิกสำเร็จ! สามารถเข้าสู่ระบบได้ทันที";

                // ล้างรหัสนักศึกษาและชื่อออกจากแบบฟอร์ม
                $student_id = '';
                $name = '';
            } else {
                // แสดงข้อความเมื่อบันทึกข้อมูลไม่สำเร็จ
                $error = "เกิดข้อผิดพลาด ไม่สามารถสมัครสมาชิกได้";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สมัครสมาชิก - สโมสรนักศึกษา</title>

    <!-- เรียกใช้ไฟล์ CSS สำหรับตกแต่งหน้าเว็บ -->
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">
    <div class="auth-card">
        <div class="auth-header">

            <!-- แสดงไอคอนและชื่อหน้าสมัครสมาชิก -->
            <div class="auth-icon">📝</div>
            <h1 class="auth-title">สมัครสมาชิก</h1>
            <p class="auth-subtitle">ระบบยืม-คืนอุปกรณ์ สโมสรนักศึกษา</p>
        </div>

        <!-- แสดงข้อความแจ้งข้อผิดพลาด หากมี -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <!-- แสดงข้อความเมื่อสมัครสมาชิกสำเร็จ -->
        <?php if ($success): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <!-- แบบฟอร์มกรอกข้อมูลสำหรับสมัครสมาชิก -->
        <form method="POST" class="form-stack">
            <div>
                <label class="auth-label">รหัสนักศึกษา</label>
                <input type="text" name="student_id" required maxlength="20" value="<?= htmlspecialchars($student_id) ?>" class="auth-input" placeholder="เช่น 66000002">
            </div>

            <div>
                <label class="auth-label">ชื่อ-นามสกุล</label>
                <input type="text" name="name" required maxlength="100" value="<?= htmlspecialchars($name) ?>" class="auth-input" placeholder="เช่น สมชาย ใจดี">
            </div>

            <div>
                <label class="auth-label">รหัสผ่าน</label>
                <input type="password" name="password" required minlength="4" class="auth-input">
            </div>

            <div>
                <label class="auth-label">ยืนยันรหัสผ่าน</label>
                <input type="password" name="confirm_password" required minlength="4" class="auth-input">
            </div>

            <!-- ปุ่มส่งข้อมูลเพื่อสมัครสมาชิก -->
            <button type="submit" class="btn-auth">สมัครสมาชิก</button>
        </form>

        <!-- ลิงก์กลับไปยังหน้าเข้าสู่ระบบสำหรับผู้ที่มีบัญชีแล้ว -->
        <p class="auth-footer spaced">
            มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบ</a>
        </p>
    </div>
</body>
</html>

<!-- โดยรวมหน้านี้ใช้สำหรับสมัครสมาชิกใหม่เข้าสู่ระบบยืม-คืนอุปกรณ์
     รับรหัสนักศึกษา ชื่อ รหัสผ่าน และการยืนยันรหัสผ่าน
     ตรวจสอบความถูกต้องของข้อมูลและป้องกันการใช้รหัสนักศึกษาซ้ำ
     เข้ารหัสผ่านก่อนบันทึกข้อมูลลงฐานข้อมูล และกำหนดสิทธิ์เป็นนักศึกษา
     จากนั้นแจ้งผลการสมัครสมาชิกให้ผู้ใช้ทราบ -->

