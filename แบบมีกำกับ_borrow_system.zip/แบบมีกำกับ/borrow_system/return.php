```php
<?php
// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db.php';

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบแล้วหรือไม่
// หากยังไม่ได้เข้าสู่ระบบ ให้กลับไปหน้า login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// ตรวจสอบว่ามีรหัสรายการยืมส่งมาทาง URL หรือไม่
if (isset($_GET['loan_id'])) {

    // กำหนดรหัสรายการยืม วันที่คืน และรหัสผู้ใช้
    $loan_id     = intval($_GET['loan_id']);
    $return_date = date('Y-m-d');
    $user_id     = (int)$_SESSION['user_id'];

    // ตรวจสอบว่าผู้ใช้เป็นแอดมินหรือไม่
    $is_admin    = ($_SESSION['role'] ?? '') === 'admin';

    // เริ่ม Transaction เพื่อให้การคืนอุปกรณ์ทำงานเป็นชุดเดียวกัน
    $conn->begin_transaction();

    try {
        // ค้นหารายการยืมที่ยังไม่คืนและล็อกข้อมูลไว้
        // เพื่อป้องกันการคืนซ้ำจนทำให้จำนวนอุปกรณ์เพิ่มเกินจริง
        $s = $conn->prepare("SELECT item_id, quantity, user_id FROM loans WHERE loan_id = ? AND status = 'active' FOR UPDATE");
        $s->bind_param("i", $loan_id);
        $s->execute();
        $loan = $s->get_result()->fetch_assoc();

        // อนุญาตให้คืนได้เฉพาะรายการของตัวเอง
        // ยกเว้นแอดมินที่สามารถคืนอุปกรณ์แทนผู้ใช้ได้
        if ($loan && ($is_admin || (int)$loan['user_id'] === $user_id)) {

            // บันทึกวันที่คืนจริงและเปลี่ยนสถานะเป็นคืนแล้ว
            $u1 = $conn->prepare("UPDATE loans SET return_date = ?, status = 'returned' WHERE loan_id = ?");
            $u1->bind_param("si", $return_date, $loan_id);
            $u1->execute();

            // เพิ่มจำนวนอุปกรณ์ที่คืนกลับเข้าไปในคลัง
            // และเปลี่ยนสถานะอุปกรณ์เป็นพร้อมให้ยืม
            $u2 = $conn->prepare("UPDATE items
                                  SET available_qty = available_qty + ?, status = 'available'
                                  WHERE item_id = ?");
            $u2->bind_param("ii", $loan['quantity'], $loan['item_id']);
            $u2->execute();
        }

        // ยืนยันการเปลี่ยนแปลงข้อมูลในฐานข้อมูล
        $conn->commit();

    } catch (Exception $e) {

        // ยกเลิกการเปลี่ยนแปลงทั้งหมด หากเกิดข้อผิดพลาด
        $conn->rollback();
    }
}

// กลับไปยังหน้าประวัติการยืม
header("Location: history.php");
exit();

// โดยรวมไฟล์นี้ใช้สำหรับจัดการการคืนอุปกรณ์
// ตรวจสอบสิทธิ์ผู้ใช้และสถานะรายการยืม ป้องกันการคืนซ้ำ
// บันทึกวันที่คืนและเปลี่ยนสถานะรายการยืมเป็นคืนแล้ว
// เพิ่มจำนวนอุปกรณ์กลับเข้าคลัง และกลับไปหน้าประวัติการยืม
?>
