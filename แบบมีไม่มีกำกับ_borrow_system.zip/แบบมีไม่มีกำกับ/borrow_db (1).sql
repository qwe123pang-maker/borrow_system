-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2026 at 06:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `borrow_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_code` varchar(20) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` enum('sports','boardgame') NOT NULL,
  `total_qty` int(11) NOT NULL DEFAULT 1,
  `available_qty` int(11) NOT NULL DEFAULT 1,
  `status` enum('available','borrowed') DEFAULT 'available',
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_code`, `item_name`, `category`, `total_qty`, `available_qty`, `status`, `image`) VALUES
(12, 'GAME-003', 'UNO', 'boardgame', 1, 1, 'available', '1791539919_6ac8bacfac845.webp'),
(13, 'SPT-002', 'ไม้แบดมินตัน Yonex', 'sports', 6, 6, 'available', '1791540228_6ac8bc0482d53.jpg'),
(14, 'GAME-001', 'บอร์ดเกม werewolf', 'boardgame', 1, 0, 'borrowed', '1791540905_6ac8bea9838c5.jpg'),
(16, 'GAME-002', 'บอร์ดเกม Exploding Kittens', 'boardgame', 1, 1, 'available', '1791541627_6ac8c17b1433c.jpg'),
(17, 'SPT-001', 'ลูกบาสเกตบอล Molten', 'sports', 1, 1, 'available', '1791541872_6ac8c2703cf43.png');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `loan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `borrow_date` date NOT NULL,
  `due_date` datetime NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('active','returned') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loans`
--

INSERT INTO `loans` (`loan_id`, `user_id`, `item_id`, `quantity`, `borrow_date`, `due_date`, `return_date`, `status`) VALUES
(5, 4, 14, 1, '2026-10-09', '2026-10-16 00:00:00', NULL, 'active'),
(6, 5, 12, 1, '2026-10-20', '2026-10-27 00:00:00', '2026-10-20', 'returned'),
(7, 5, 13, 1, '2026-10-20', '2026-10-27 00:00:00', '2026-10-20', 'returned');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','admin') DEFAULT 'student'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `student_id`, `name`, `password`, `role`) VALUES
(1, '66000001', 'สมชาย สายลุย (นักศึกษา)', '1234', 'student'),
(2, 'admin', 'แอดมินสโมสร', '1234', 'admin'),
(3, '6710510217', 'ปังเทพ สุระคำแหง', '$2y$10$mo6tZlis3XEDdZN8NBs5NubevP0oZgogNcDKVdhY0OoVPYdBZpdzC', 'student'),
(4, '6710510024', 'กานต์ สร้อยสน', '$2y$10$Zt.DFaIlkJrNk0p9QX63YO1b2zHEwHjDONmaEEPlbzRd95NbvFGD6', 'student'),
(5, '6710610141', 'นายวรินทร หนูสง', '$2y$10$M9reu60022O9XZNGASfTvO9GPNDT1Ay2vQOfa97C9GK23DtlepeIq', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `item_code` (`item_code`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`loan_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `student_id` (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
