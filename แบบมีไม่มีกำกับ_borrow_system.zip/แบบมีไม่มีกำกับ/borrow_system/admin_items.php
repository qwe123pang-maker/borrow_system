<?php
require_once 'db.php';
require_once 'navbar.php';

if ($_SESSION['role'] !== 'admin') {
    die("<div class='msg-error-page'>สำหรับแอดมินเท่านั้น</div>");
}

$msg_ok = '';
$msg_err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'add';

    // ==================== เพิ่มอุปกรณ์ ====================
    if ($action === 'add') {
        $item_code = trim($_POST['item_code']);
        $item_name = trim($_POST['item_name']);
        $category  = $_POST['category'] === 'boardgame' ? 'boardgame' : 'sports';
        $qty       = intval($_POST['total_qty'] ?? 1);
        $image_name = NULL;

        if ($qty < 1) {
            $msg_err = "จำนวนต้องอย่างน้อย 1 ชิ้น";
        } else {
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                    $image_name = time() . '_' . uniqid() . '.' . $ext;
                    if (!is_dir('uploads')) {
                        mkdir('uploads', 0755, true);
                    }
                    move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $image_name);
                }
            }

            // จำนวนทั้งหมด = จำนวนคงเหลือ ตอนเพิ่มใหม่
            $stmt = $conn->prepare(
                "INSERT INTO items (item_code, item_name, category, total_qty, available_qty, image, status)
                 VALUES (?, ?, ?, ?, ?, ?, 'available')"
            );
            $stmt->bind_param("sssiis", $item_code, $item_name, $category, $qty, $qty, $image_name);
            $stmt->execute();

            header("Location: admin_items.php?ok=added");
            exit();
        }
    }

    // ==================== ปรับจำนวนอุปกรณ์ ====================
    if ($action === 'set_qty') {
        $item_id = intval($_POST['item_id']);
        $new_total = intval($_POST['total_qty']);

        $conn->begin_transaction();
        $s = $conn->prepare("SELECT total_qty, available_qty FROM items WHERE item_id = ? FOR UPDATE");
        $s->bind_param("i", $item_id);
        $s->execute();
        $it = $s->get_result()->fetch_assoc();

        if (!$it) {
            $conn->rollback();
            $msg_err = "ไม่พบอุปกรณ์";
        } else {
            $borrowed = (int)$it['total_qty'] - (int)$it['available_qty'];
            if ($new_total < $borrowed || $new_total < 0) {
                $conn->rollback();
                $msg_err = "ปรับไม่ได้ ขณะนี้มีของถูกยืมอยู่ $borrowed ชิ้น (จำนวนทั้งหมดต้องไม่น้อยกว่านี้)";
            } else {
                $new_avail = $new_total - $borrowed;
                $u = $conn->prepare("UPDATE items
                                     SET total_qty = ?, available_qty = ?,
                                         status = IF(? > 0, 'available', 'borrowed')
                                     WHERE item_id = ?");
                $u->bind_param("iiii", $new_total, $new_avail, $new_avail, $item_id);
                $u->execute();
                $conn->commit();
                header("Location: admin_items.php?ok=qty");
                exit();
            }
        }
    }

    // ==================== ลบอุปกรณ์ ====================
    if ($action === 'delete') {
        $item_id = intval($_POST['item_id']);

        // ห้ามลบถ้ามีรายการยืมที่ยังไม่คืน
        $c = $conn->prepare("SELECT COUNT(*) AS n FROM loans WHERE item_id = ? AND status = 'active'");
        $c->bind_param("i", $item_id);
        $c->execute();
        $active = (int)$c->get_result()->fetch_assoc()['n'];

        if ($active > 0) {
            $msg_err = "ลบไม่ได้ เพราะยังมีรายการยืมที่ยังไม่คืน";
        } else {
            $q = $conn->prepare("SELECT image FROM items WHERE item_id = ?");
            $q->bind_param("i", $item_id);
            $q->execute();
            $img = $q->get_result()->fetch_assoc();
            if (!empty($img['image']) && file_exists('uploads/' . $img['image'])) {
                unlink('uploads/' . $img['image']);
            }
            $d = $conn->prepare("DELETE FROM items WHERE item_id = ?");
            $d->bind_param("i", $item_id);
            try {
                $d->execute();
                header("Location: admin_items.php?ok=deleted");
                exit();
            } catch (Exception $e) {
                // ถ้ามีประวัติการยืมเก่าผูกอยู่ (foreign key)
                $msg_err = "ลบไม่ได้ เพราะมีประวัติการยืมของอุปกรณ์นี้อยู่ในระบบ";
            }
        }
    }
}

if (isset($_GET['ok'])) {
    $labels = ['added' => 'เพิ่มอุปกรณ์แล้ว', 'qty' => 'ปรับจำนวนเรียบร้อย', 'deleted' => 'ลบอุปกรณ์แล้ว'];
    $msg_ok = $labels[$_GET['ok']] ?? '';
}

$items = $conn->query("SELECT * FROM items ORDER BY item_id DESC");
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการอุปกรณ์ (แอดมิน)</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>
<body class="bg-page">
<div class="container">

    <h1 class="page-title">⚙️ เพิ่ม / ปรับจำนวน / ลบ อุปกรณ์ (แอดมิน)</h1>

    <?php if ($msg_ok): ?><div class="flash flash-success"><?= htmlspecialchars($msg_ok) ?></div><?php endif; ?>
    <?php if ($msg_err): ?><div class="flash flash-error"><?= htmlspecialchars($msg_err) ?></div><?php endif; ?>

    <div class="card card-padded">
        <h2 class="card-title">เพิ่มรายการอุปกรณ์ใหม่</h2>

        <form method="POST" enctype="multipart/form-data" class="form-grid">
            <input type="hidden" name="action" value="add">

            <div>
                <label class="form-label">รหัสอุปกรณ์</label>
                <input type="text" name="item_code" required placeholder="เช่น SPT-003" class="form-input">
            </div>
            <div>
                <label class="form-label">ชื่ออุปกรณ์</label>
                <input type="text" name="item_name" required placeholder="เช่น ลูกบาสเกตบอล" class="form-input">
            </div>
            <div>
                <label class="form-label">หมวดหมู่</label>
                <select name="category" class="form-select">
                    <option value="sports">อุปกรณ์กีฬา</option>
                    <option value="boardgame">บอร์ดเกม</option>
                </select>
            </div>
            <div>
                <label class="form-label">จำนวน (ชิ้น)</label>
                <input type="number" name="total_qty" min="1" value="1" required class="form-input">
            </div>
            <div>
                <label class="form-label">รูปภาพอุปกรณ์</label>
                <input type="file" name="image" accept="image/*" class="form-file">
            </div>
            <div class="form-field-wide">
                <button type="submit" class="btn btn-primary">+ บันทึกอุปกรณ์</button>
            </div>
        </form>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>รูป</th>
                    <th>รหัส</th>
                    <th>ชื่ออุปกรณ์</th>
                    <th>หมวดหมู่</th>
                    <th>คงเหลือ / ถูกยืม</th>
                    <th>ปรับจำนวนทั้งหมด</th>
                    <th>สถานะ</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $items->fetch_assoc()): ?>
                <?php
                    $total = (int)$row['total_qty'];
                    $avail = (int)$row['available_qty'];
                    $borrowed = $total - $avail;
                ?>
                <tr>
                    <td>
                        <?php if (!empty($row['image']) && file_exists('uploads/' . $row['image'])): ?>
                            <img src="uploads/<?= htmlspecialchars($row['image']) ?>" class="thumb">
                        <?php else: ?>
                            <div class="thumb-empty">ไม่มีรูป</div>
                        <?php endif; ?>
                    </td>
                    <td class="cell-code"><?= htmlspecialchars($row['item_code']) ?></td>
                    <td class="cell-name"><?= htmlspecialchars($row['item_name']) ?></td>
                    <td class="cell-muted"><?= $row['category'] == 'sports' ? '⚽ กีฬา' : '🎲 บอร์ดเกม' ?></td>
                    <td>
                        <span class="qty-badge"><?= $avail ?> / <?= $total ?></span>
                        <div class="cell-muted" style="font-size:.75rem">ถูกยืม <?= $borrowed ?> ชิ้น</div>
                    </td>
                    <td>
                        <form method="POST" class="qty-form">
                            <input type="hidden" name="action" value="set_qty">
                            <input type="hidden" name="item_id" value="<?= $row['item_id'] ?>">
                            <input type="number" name="total_qty" min="<?= $borrowed ?>" value="<?= $total ?>" required>
                            <button type="submit" class="btn-small">บันทึก</button>
                        </form>
                    </td>
                    <td>
                        <span class="badge <?= $avail > 0 ? 'badge-available' : 'badge-borrowed' ?>">
                            <?= $avail > 0 ? 'ว่าง' : 'ถูกยืมหมด' ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" onsubmit="return confirm('ยืนยันการลบ?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="item_id" value="<?= $row['item_id'] ?>">
                            <button type="submit" class="btn-del">ลบ</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>
