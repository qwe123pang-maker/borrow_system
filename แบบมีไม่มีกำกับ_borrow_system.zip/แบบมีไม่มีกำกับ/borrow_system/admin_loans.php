<?php
require_once 'db.php';
require_once 'navbar.php';

if ($_SESSION['role'] !== 'admin') {
    die("<div class='msg-error-page'>สำหรับแอดมินเท่านั้น</div>");
}

$sql = "SELECT l.*, u.name as user_name, u.student_id, i.item_code, i.item_name
        FROM loans l
        JOIN users u ON l.user_id = u.user_id
        JOIN items i ON l.item_id = i.item_id
        ORDER BY l.loan_id DESC";
$loans = $conn->query($sql);

$now = date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>รายการยืมทั้งหมด (แอดมิน)</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>
<body class="bg-page">
<div class="container">
    <h1 class="page-title">📊 รายการยืมทั้งหมดในระบบ (แอดมิน)</h1>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ผู้ยืม</th>
                    <th>อุปกรณ์</th>
                    <th>จำนวน</th>
                    <th>วันที่ยืม</th>
                    <th>กำหนดคืน</th>
                    <th>วันที่คืนจริง</th>
                    <th>สถานะ</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $loans->fetch_assoc()): ?>
                <?php $is_overdue = ($row['status'] === 'active' && $now > $row['due_date']); ?>

                <tr class="<?= $is_overdue ? 'row-overdue' : '' ?>">
                    <td>
                        <?= htmlspecialchars($row['user_name']) ?>
                        (<?= htmlspecialchars($row['student_id']) ?>)
                    </td>
                    <td>
                        [<?= htmlspecialchars($row['item_code']) ?>]
                        <?= htmlspecialchars($row['item_name']) ?>
                    </td>
                    <td><span class="qty-badge">× <?= (int)$row['quantity'] ?></span></td>
                    <td><?= $row['borrow_date'] ?></td>
                    <td class="cell-due <?= $is_overdue ? 'is-overdue' : '' ?>">
                        <?= date('d/m/Y H:i', strtotime($row['due_date'])) ?>
                        <?= $is_overdue ? '<span class="badge-overdue">⚠️ เกินกำหนด</span>' : '' ?>
                    </td>
                    <td><?= $row['return_date'] ?: '-' ?></td>
                    <td>
                        <?= $row['status'] == 'active'
                            ? '<span class="text-pending">ยังไม่คืน</span>'
                            : '<span class="text-done">คืนแล้ว</span>' ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
