<?php
require_once 'db.php';

// ต้องเข้าสู่ระบบ และส่งข้อมูลแบบ POST เท่านั้น
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

$user_id  = (int)$_SESSION['user_id'];
$item_id  = intval($_POST['item_id'] ?? 0);
$qty      = intval($_POST['quantity'] ?? 0);
$due_raw  = trim($_POST['due_datetime'] ?? '');

// ฟังก์ชันส่งข้อความผิดพลาดกลับหน้าแรก
function fail($msg) {
    $_SESSION['flash_error'] = $msg;
    header("Location: index.php");
    exit();
}

if ($item_id <= 0 || $qty < 1) {
    fail("ข้อมูลไม่ถูกต้อง กรุณาระบุจำนวนอย่างน้อย 1 ชิ้น");
}

// ตรวจสอบวันและเวลาคืน: ต้องอยู่หลังตอนนี้ และไม่เกิน 7 วัน
$due = DateTime::createFromFormat('Y-m-d\TH:i', $due_raw);
if (!$due) {
    fail("รูปแบบวันและเวลาคืนไม่ถูกต้อง");
}
$now = new DateTime();
$max = (clone $now)->modify('+7 days');
if ($due <= $now) {
    fail("กำหนดคืนต้องเป็นเวลาในอนาคต");
}
if ($due > $max) {
    fail("ยืมได้ไม่เกิน 7 วัน");
}

$borrow_date = $now->format('Y-m-d');
$due_date    = $due->format('Y-m-d H:i:s');

// ใช้ transaction + ล็อกแถว ป้องกันสองคนยืมพร้อมกันแล้วของติดลบ
$conn->begin_transaction();
try {
    $s = $conn->prepare("SELECT available_qty FROM items WHERE item_id = ? FOR UPDATE");
    $s->bind_param("i", $item_id);
    $s->execute();
    $item = $s->get_result()->fetch_assoc();

    if (!$item) {
        throw new Exception("ไม่พบอุปกรณ์นี้");
    }
    if ($qty > (int)$item['available_qty']) {
        throw new Exception("จำนวนไม่พอ เหลือให้ยืม " . (int)$item['available_qty'] . " ชิ้น");
    }

    $ins = $conn->prepare("INSERT INTO loans (user_id, item_id, quantity, borrow_date, due_date) VALUES (?, ?, ?, ?, ?)");
    $ins->bind_param("iiiss", $user_id, $item_id, $qty, $borrow_date, $due_date);
    $ins->execute();

    // หักจำนวนคงเหลือ และอัปเดตสถานะตามจำนวนที่เหลือ
    $upd = $conn->prepare("UPDATE items
                           SET available_qty = available_qty - ?,
                               status = IF(available_qty > 0, 'available', 'borrowed')
                           WHERE item_id = ?");
    $upd->bind_param("ii", $qty, $item_id);
    $upd->execute();

    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    fail($e->getMessage());
}

header("Location: history.php");
exit();
