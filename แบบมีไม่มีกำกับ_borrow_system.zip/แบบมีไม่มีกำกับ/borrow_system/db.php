<?php
// ตั้งเขตเวลาให้ตรงกับประเทศไทย เพื่อให้เวลายืม/คืนถูกต้อง
date_default_timezone_set('Asia/Bangkok');

// เชื่อมต่อฐานข้อมูล borrow_db
$conn = new mysqli("localhost", "root", "", "borrow_db");

// กำหนดให้ฐานข้อมูลรองรับภาษาไทยและอักขระพิเศษ
$conn->set_charset("utf8mb4");

// ตรวจสอบว่าการเชื่อมต่อฐานข้อมูลสำเร็จหรือไม่
if ($conn->connect_error) {
    die("เชื่อมต่อฐานข้อมูลล้มเหลว: " . $conn->connect_error);
}

// เริ่มต้น Session หากยังไม่ได้เริ่ม
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
