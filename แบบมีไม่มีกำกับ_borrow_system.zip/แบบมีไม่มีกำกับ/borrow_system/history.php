<?php
require_once 'db.php';
require_once 'navbar.php';

$user_id = $_SESSION['user_id'];

$sql = "SELECT l.*, i.item_code, i.item_name, i.image
        FROM loans l
        JOIN items i ON l.item_id = i.item_id
        WHERE l.user_id = ?
        ORDER BY l.loan_id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// เวลาปัจจุบัน (วันที่+เวลา) ใช้ตรวจเกินกำหนด
$now = date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ประวัติการยืม</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>
<body class="bg-page">
<div class="container">
    <h1 class="page-title">📋 ประวัติการยืมของคุณ</h1>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>รูป</th>
                    <th>รหัส</th>
                    <th>อุปกรณ์</th>
                    <th>จำนวน</th>
                    <th>วันที่ยืม</th>
                    <th>กำหนดคืน</th>
                    <th>วันที่คืนจริง</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <?php $is_overdue = ($row['status'] === 'active' && $now > $row['due_date']); ?>

                <tr class="<?= $is_overdue ? 'row-overdue' : '' ?>">
                    <td>
                        <?php if (!empty($row['image']) && file_exists('uploads/' . $row['image'])): ?>
                            <img src="uploads/<?= htmlspecialchars($row['image']) ?>" class="thumb">
                        <?php else: ?>
                            <div class="thumb-empty">ไม่มีรูป</div>
                        <?php endif; ?>
                    </td>
                    <td class="cell-code"><?= htmlspecialchars($row['item_code']) ?></td>
                    <td class="cell-name"><?= htmlspecialchars($row['item_name']) ?></td>
                    <td><span class="qty-badge">× <?= (int)$row['quantity'] ?></span></td>
                    <td class="cell-muted"><?= $row['borrow_date'] ?></td>
                    <td class="cell-due <?= $is_overdue ? 'is-overdue' : '' ?>">
                        <?= date('d/m/Y H:i', strtotime($row['due_date'])) ?>
                        <?= $is_overdue ? ' <span class="badge-overdue">เกินกำหนด</span>' : '' ?>
                    </td>
                    <td class="cell-muted"><?= $row['return_date'] ?: '-' ?></td>
                    <td>
                        <?php if ($row['status'] == 'active'): ?>
                            <a href="return.php?loan_id=<?= $row['loan_id'] ?>" class="btn-return" onclick="return confirm('ยืนยันนำของมาคืนแล้ว?')">คืนอุปกรณ์</a>
                        <?php else: ?>
                            <span class="badge badge-returned">คืนเรียบร้อย</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
