<?php
require_once 'db.php';
require_once 'navbar.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$sql = "SELECT * FROM items WHERE item_name LIKE ? OR item_code LIKE ? ORDER BY item_id DESC";
$stmt = $conn->prepare($sql);
$param = "%$search%";
$stmt->bind_param("ss", $param, $param);
$stmt->execute();
$result = $stmt->get_result();

// ข้อความแจ้งผลจากการยืม
$flash_error = $_SESSION['flash_error'] ?? '';
unset($_SESSION['flash_error']);

// ช่วงเวลาที่เลือกคืนได้ (ตอนนี้ ถึง +7 วัน)
$min_dt     = date('Y-m-d\TH:i');
$max_dt     = date('Y-m-d\TH:i', strtotime('+7 days'));
$default_dt = $max_dt;
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>รายการอุปกรณ์</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style_qty.css">
</head>
<body class="bg-page">
<div class="container">
    <div class="toolbar">
        <div>
            <h1 class="page-title">📦 รายการอุปกรณ์กีฬา และ บอร์ดเกม</h1>
            <p class="page-subtitle">เลือกอุปกรณ์ จำนวน และกำหนดวันเวลาคืน (ไม่เกิน 7 วัน)</p>
        </div>

        <form method="GET" class="search-form">
            <input type="text" name="search" placeholder="ค้นหาชื่อหรือรหัส..." value="<?= htmlspecialchars($search) ?>" class="search-input">
            <button type="submit" class="btn-search">ค้นหา</button>
        </form>
    </div>

    <?php if ($flash_error): ?>
        <div class="flash flash-error"><?= htmlspecialchars($flash_error) ?></div>
    <?php endif; ?>

    <div class="item-grid">
        <?php while($row = $result->fetch_assoc()): ?>
            <?php $avail = (int)$row['available_qty']; ?>
            <div class="item-card">
                <div class="item-image">
                    <?php if (!empty($row['image']) && file_exists('uploads/' . $row['image'])): ?>
                        <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="">
                    <?php else: ?>
                        <div class="item-noimage">
                            <span>📷</span>
                            <p>ไม่มีรูปภาพ</p>
                        </div>
                    <?php endif; ?>

                    <span class="item-status <?= $avail > 0 ? 'available' : 'borrowed' ?>">
                        <?= $avail > 0 ? 'พร้อมยืม' : 'ถูกยืมหมดแล้ว' ?>
                    </span>
                </div>

                <div class="item-body">
                    <div>
                        <div class="item-meta">
                            <span class="item-code"><?= htmlspecialchars($row['item_code']) ?></span>
                            <span class="item-category"><?= $row['category'] == 'sports' ? '⚽ กีฬา' : '🎲 บอร์ดเกม' ?></span>
                        </div>
                        <h3 class="item-name"><?= htmlspecialchars($row['item_name']) ?></h3>
                        <p class="stock-info">คงเหลือ <b><?= $avail ?></b> / <?= (int)$row['total_qty'] ?> ชิ้น</p>
                    </div>

                    <div>
                        <?php if ($avail > 0): ?>
                            <form method="POST" action="borrow.php" class="borrow-form"
                                  onsubmit="return confirm('ยืนยันการทำรายการยืม?')">
                                <input type="hidden" name="item_id" value="<?= (int)$row['item_id'] ?>">
                                <div>
                                    <label>จำนวนที่ต้องการยืม</label>
                                    <input type="number" name="quantity" min="1" max="<?= $avail ?>" value="1" required>
                                </div>
                                <div>
                                    <label>วันและเวลาคืน</label>
                                    <input type="datetime-local" name="due_datetime"
                                           min="<?= $min_dt ?>" max="<?= $max_dt ?>"
                                           value="<?= $default_dt ?>" required>
                                    <span class="hint">เลือกได้ไม่เกิน 7 วันนับจากตอนนี้</span>
                                </div>
                                <button type="submit" class="btn-borrow">ยืมอุปกรณ์นี้</button>
                            </form>
                        <?php else: ?>
                            <button disabled class="btn-disabled">ไม่พร้อมบริการ</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>
