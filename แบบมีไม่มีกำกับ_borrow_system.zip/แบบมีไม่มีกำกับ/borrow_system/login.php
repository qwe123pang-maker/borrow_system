<?php
require_once 'db.php';
$error = '';
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id']);
    $password = trim($_POST['password']);
 
    $stmt = $conn->prepare("SELECT * FROM users WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
 
    // รองรับทั้งรหัสผ่านที่เข้ารหัสแล้ว (สมัครใหม่) และบัญชีเก่าที่เป็นข้อความธรรมดา
    $valid = $user && (password_verify($password, $user['password']) || hash_equals($user['password'], $password));
 
    if ($valid) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        header("Location: index.php");
        exit();
    } else {
        $error = "รหัสผู้ใช้ หรือรหัสผ่านไม่ถูกต้อง!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>เข้าสู่ระบบ - สโมสรนักศึกษา</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-icon">⚽</div>
            <h1 class="auth-title">ระบบยืม-คืนอุปกรณ์</h1>
            <p class="auth-subtitle">สโมสรนักศึกษา</p>
        </div>
 
        <?php if($error): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
 
        <form method="POST" class="form-stack">
            <div>
                <label class="auth-label">รหัสนักศึกษา / แอดมิน</label>
                <input type="text" name="student_id" required class="auth-input" placeholder="เช่น 66000001 หรือ admin">
            </div>
            <div>
                <label class="auth-label">รหัสผ่าน</label>
                <input type="password" name="password" required class="auth-input" placeholder="1234">
            </div>
            <button type="submit" class="btn-auth">เข้าสู่ระบบ</button>
        </form>
 
        <p class="auth-footer">
            ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a>
        </p>
 
        <div class="test-box">
            <p class="test-box-title">บัญชีสำหรับทดสอบ:</p>
            <p>• นักศึกษา: <code>66000001</code> / รหัสผ่าน <code>1234</code></p>
            <p>• แอดมิน: <code>admin</code> / รหัสผ่าน <code>1234</code></p>
        </div>
    </div>
</body>
</html>
