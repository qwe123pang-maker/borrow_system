<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<link rel="stylesheet" href="style.css">
<nav class="navbar">
    <div class="navbar-inner">
        <div class="navbar-left">
            <a href="index.php" class="navbar-brand">
                <span>⚽</span>
                <span>สโมสรนักศึกษา</span>
            </a>
            <a href="index.php" class="nav-link">รายการอุปกรณ์</a>
            <a href="history.php" class="nav-link">ประวัติการยืม</a>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="admin_items.php" class="nav-admin">⚙️ [แอดมิน] จัดการอุปกรณ์</a>
                <a href="admin_loans.php" class="nav-admin">📊 [แอดมิน] การยืมทั้งหมด</a>
            <?php endif; ?>
        </div>
        <div class="navbar-right">
            <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['name']) ?></span>
            <a href="logout.php" class="btn-logout">ออกจากระบบ</a>
        </div>
    </div>
</nav>
