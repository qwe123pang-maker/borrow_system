<?php
require_once 'db.php';

// ถ้าล็อกอินอยู่แล้วไม่ต้องสมัครซ้ำ
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';
$student_id = '';
$name = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($student_id === '' || $name === '' || $password === '') {
        $error = "กรุณากรอกข้อมูลให้ครบทุกช่อง";
    } elseif (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $student_id)) {
        $error = "รหัสนักศึกษาต้องเป็นตัวอักษร/ตัวเลข 3-20 ตัว";
    } elseif (mb_strlen($name) > 100) {
        $error = "ชื่อยาวเกินไป";
    } elseif (strlen($password) < 4) {
        $error = "รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร";
    } elseif ($password !== $confirm) {
        $error = "รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน";
    } else {
        $chk = $conn->prepare("SELECT user_id FROM users WHERE student_id = ?");
        $chk->bind_param("s", $student_id);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $error = "รหัสนี้ถูกใช้งานแล้ว";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'student'; // สมัครเองได้เฉพาะนักศึกษา ไม่สามารถเป็นแอดมินได้
            $stmt = $conn->prepare("INSERT INTO users (student_id, name, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $student_id, $name, $hash, $role);
            if ($stmt->execute()) {
                $success = "สมัครสมาชิกสำเร็จ! สามารถเข้าสู่ระบบได้ทันที";
                $student_id = '';
                $name = '';
            } else {
                $error = "เกิดข้อผิดพลาด ไม่สามารถสมัครสมาชิกได้";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สมัครสมาชิก - สโมสรนักศึกษา</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-icon">📝</div>
            <h1 class="auth-title">สมัครสมาชิก</h1>
            <p class="auth-subtitle">ระบบยืม-คืนอุปกรณ์ สโมสรนักศึกษา</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="form-stack">
            <div>
                <label class="auth-label">รหัสนักศึกษา</label>
                <input type="text" name="student_id" required maxlength="20" value="<?= htmlspecialchars($student_id) ?>" class="auth-input" placeholder="เช่น 66000002">
            </div>
            <div>
                <label class="auth-label">ชื่อ-นามสกุล</label>
                <input type="text" name="name" required maxlength="100" value="<?= htmlspecialchars($name) ?>" class="auth-input" placeholder="เช่น สมชาย ใจดี">
            </div>
            <div>
                <label class="auth-label">รหัสผ่าน</label>
                <input type="password" name="password" required minlength="4" class="auth-input">
            </div>
            <div>
                <label class="auth-label">ยืนยันรหัสผ่าน</label>
                <input type="password" name="confirm_password" required minlength="4" class="auth-input">
            </div>
            <button type="submit" class="btn-auth">สมัครสมาชิก</button>
        </form>

        <p class="auth-footer spaced">
            มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบ</a>
        </p>
    </div>
</body>
</html>
