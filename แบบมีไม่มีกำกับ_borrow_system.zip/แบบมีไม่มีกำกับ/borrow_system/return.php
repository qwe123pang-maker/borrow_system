<?php
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['loan_id'])) {
    $loan_id     = intval($_GET['loan_id']);
    $return_date = date('Y-m-d');
    $user_id     = (int)$_SESSION['user_id'];
    $is_admin    = ($_SESSION['role'] ?? '') === 'admin';

    $conn->begin_transaction();
    try {
        // ล็อกรายการยืม และตรวจว่ายังไม่คืน (กันคืนซ้ำแล้วจำนวนเพิ่มเกิน)
        $s = $conn->prepare("SELECT item_id, quantity, user_id FROM loans WHERE loan_id = ? AND status = 'active' FOR UPDATE");
        $s->bind_param("i", $loan_id);
        $s->execute();
        $loan = $s->get_result()->fetch_assoc();

        // คืนได้เฉพาะรายการของตัวเอง (แอดมินคืนแทนได้)
        if ($loan && ($is_admin || (int)$loan['user_id'] === $user_id)) {
            $u1 = $conn->prepare("UPDATE loans SET return_date = ?, status = 'returned' WHERE loan_id = ?");
            $u1->bind_param("si", $return_date, $loan_id);
            $u1->execute();

            // คืนจำนวนกลับเข้าคลัง
            $u2 = $conn->prepare("UPDATE items
                                  SET available_qty = available_qty + ?, status = 'available'
                                  WHERE item_id = ?");
            $u2->bind_param("ii", $loan['quantity'], $loan['item_id']);
            $u2->execute();
        }
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
    }
}

header("Location: history.php");
exit();
